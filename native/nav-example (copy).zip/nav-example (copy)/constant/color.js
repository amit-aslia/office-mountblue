export default{
    primary:"#4a148c",
    accent:"#ff6f00"
}