import React from 'react'
import {View,Text,StyleSheet} from 'react-native'
const FavouriteScreen = () => {
    return (
        <View>
            <Text>Favourites Screen</Text>
        </View>
    )
}

FavouriteScreen.navigationOptions={
    headerTitle:'Favourites'
}

export default FavouriteScreen
